function loadData(branch = "all") {
    fetch("api.php?branch=" + branch)
        .then(res => res.json())
        .then(data => {

            // KPI
            document.getElementById("sales").innerText = data.total_sales;
            document.getElementById("orders").innerText = data.total_orders;
            document.getElementById("rating").innerText = data.avg_rating;

            // BAR CHART
            new Chart(document.getElementById("barChart"), {
                type: "bar",
                data: {
                    labels: data.chart.branches,
                    datasets: [{
                        label: "Sales",
                        data: data.chart.sales
                    }]
                }
            });

            // LINE CHART
            new Chart(document.getElementById("lineChart"), {
                type: "line",
                data: {
                    labels: data.chart.months,
                    datasets: [{
                        label: "Trend",
                        data: data.chart.trend
                    }]
                }
            });

            // PIE CHART
            new Chart(document.getElementById("pieChart"), {
                type: "pie",
                data: {
                    labels: data.chart.categories,
                    datasets: [{
                        data: data.chart.category_values
                    }]
                }
            });
        });
}

/* FILTER EVENT */
document.getElementById("branchFilter").addEventListener("change", function () {
    loadData(this.value);
});

/* INITIAL LOAD */
loadData();